<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css
" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body style="margin: 50px;">
    <h1>List of Patients</h1>
    <br>
    <table class="table">
        <thead>
			<tr>
				<th>Personid</th>
				<th>FullName</th>
                <th>Phone</th>
                <th>address</th>
                <th>temperature</th>
                <th>time</th>
               
				
			</tr>
		</thead>

        <tbody>
            <?php
            $servername = "0.0.0.0";
			$username = "robolife";
			$password = "pmpathak1234";
			$database = "robo";

			// Create connection
			$connection = new mysqli($servername, $username, $password, $database);

            // Check connection
			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}

            // read all row from database table
			$sql = "SELECT * FROM Persons";
			$result = $connection->query($sql);

            if (!$result) {
				die("Invalid query: " . $connection->error);
			}

            //Declaring a delete function
            
            // read data of each row
			while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["Personid"] . "</td>
                    <td>" . $row["FullName"] . "</td>
                    <td>" . $row["Phone"] . "</td>
                    <td>" . $row["address"] . "</td>
                    <td>" . $row["temperature"] . "</td>
                    <td>" . $row["time"] . "</td>
                    <td>
                        <a class='btn btn-primary btn-sm' href='update.php? id=".$row['Personid']." & nm=".$row['FullName']." & ph=".$row['Phone']." & ad=".$row['address']." & tp=".$row['temperature']." & tm=".$row['time']." '>Update</a>
                        <a class='btn btn-danger btn-sm' href='delete.php?id=".$row['Personid']."' id='btn'>Delete</a>
                    </td>
                    
                </tr>";
            }

            $connection->close();
            ?>
        </tbody>
    </table>
</body>
</html>
