<?php
$id= filter_input(INPUT_POST, 'Personid');
$FullName = filter_input(INPUT_POST, 'FullName');
$Phone = filter_input(INPUT_POST, 'Phone');
$address = filter_input(INPUT_POST, 'address');
$temperature = filter_input(INPUT_POST, 'temperature');
$time = filter_input(INPUT_POST, 'time');
// $disease = filter_input(INPUT_POST, 'disease');
// $username = "lucfr";
// $password = "Dimple";

if (!empty($id)){
if (!empty($FullName)){
    $host = "0.0.0.0";
    $username = "robolife";
    $password = "pmpathak1234";
    $database = "robo";

// Create connection
$conn = new mysqli ($host, $username, $password, $database);


if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO Persons(id,FullName,Phone,address,temperature,time) VALUES('$id','$FullName','$Phone','$address','$temperature','$time')";
if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."<br>". $conn->error;  
}
$conn->close();
}
}
else{
echo "Fields should not be empty";
die();
}
}
else{
echo "ID should not be empty";
die();
}
?>
