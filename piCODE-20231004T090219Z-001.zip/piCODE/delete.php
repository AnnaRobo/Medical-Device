<?php   
 include 'connection.php';  
 if (isset($_GET['id'])) {  
      $id = $_GET['id'];  
      $query = "DELETE FROM `robolife` WHERE Personid = '$id'";  
      $run = mysqli_query($conn,$query);  
      if ($run) {  
           header('location:secondIndex.php');  
      }else{  
           echo "Error: ".mysqli_error($conn);  
      }  
 }  
 ?>  