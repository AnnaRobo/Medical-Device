<?php   
 include 'connection.php'; 
 error_reporting(0);
 $id = $_GET['id'];
 $nm = $_GET['nm'];
 $ph = $_GET['ph'];
 $ad = $_GET['ad'];
 $tp = $_GET['tp'];
 $tm = $_GET['tm'];

 ?>  



<!DOCTYPE html>
<html>
    <head>
        <title>HealthCare</title>
        <link rel="icon" href="https://github.com/CyberBoyAyush/Portfolio/blob/master/profile.png" type="image/x-icon">
        <link href="https://fonts.googleapis.com/css2?family=Bellota&display=swap" rel="stylesheet">
        <link href="style.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div id="header" class="section">
            <p>MedicalDevice</p>
            <img alt="logo" class="img-circle" src="HealthCareLogo.jpg"  > 
            
        </div>
        <div id="profile" class="section" >
            
            <h1><span>Patient Profile</span></h1>
            
            <form action="" method="GET" >
                <div>
                    <label for="Personid">PersonID:</label>
                    <input type="number"  value=<?php echo "$id" ?>  name="Personid" id="Personid" required>
                    

                </div>
                <div>
                    <label for="FullName">Full Name:</label>
                    <input type="text" value=<?php echo "$nm" ?>  name="FullName" id="FullName" required>
                </div>
        
                <div>
                    <label for="Phone">Phone:</label>
                    <input type="text" value=<?php echo "$ph" ?> name="Phone" id="Phone" >
                </div>
                <div>
                    <label for="address">Address:</label>
                    <input type="text" value=<?php echo "$ad" ?> name="address" id="address" >
                </div>
                
                <div>
                    <label for="temperature">Temperature:</label>
                    <input type="number" value=<?php echo "$tp" ?> name="temperature" id="temperature" >
                    
                </div>
                <div>
                    <label for="time">Time:</label>
                    <input type="datetime" value=<?php echo "$tm" ?> name="time" id="time" >
                    
                </div>
                <div>
                    <img src="https://bchellaney.files.wordpress.com/2014/12/job_9086.jpg" style="object-position:right;margin-left: -40%; margin-top: -50%;" >
                </div>
                
              <button type="reset" style='margin-right: 100px;margin-left: -250px; position: relative ; font-size: 17pt; margin-bottom: 50px; margin-top: 50px;' >Change Photo</button>
              <button type="submit" style='margin-right:500px ; font-size: 17pt; margin-bottom: 50px; margin-top: 50px;'>Save Changes</button>
              <input type="submit" id = "button" name="submit" value="Update Details"/>
            </form>

        </div>

        <div class="section" id="res">
            <p><Details>Here Doctor can write about the details of the Patient, like, his/ her disease or about the improvement.</Details></p>
        </div>
    </body>
    </html>
    


<?php

if($_GET['submit'])
{
    echo "entered here!";
    $name = $_GET['FullName'];
    $phone = $_GET['Phone'];
    $address = $_GET['address'];
    $temperature = $_GET['temperature'];   
    $time = $_GET['time'];
    
    echo "entered here!";
    //here i am changing password only bcz i am using username as id so I can't change it 
    $query="UPDATE Persons SET FullName= '$name', phone= '$phone',address= '$address',temperature= '$temperature',time= '$time'  WHERE Personid='$id'";
    $data = mysqli_query($conn,$query);
    echo "entered here!";
    if($data)
    {
        echo "<script>alert( 'Successfully updated' )</script>";
        header("refresh:1; url=secondIndex.php");
    }
    else{
        echo "Failed to update";
    }

}

?> 