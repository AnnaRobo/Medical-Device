<?php
            $servername = "0.0.0.0";
			$username = "robolife";
			$password = "pmpathak1234";
			$database = "robo";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $database);

            // Check connection
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}

?>

